// Import required Bot Framework classes.

const { DialogBot } = require('./dialogBot');

// Welcomed User Property name
const WELCOMED_USER = 'welcomedUserProperty';

class WelcomeBot extends DialogBot {
    /**
     *
     * @param {UserState} User state to persist boolean flag to indicate
     *                    if the bot had already welcomed the user
     */

    constructor(conversationState, userState, dialog) {
        super(conversationState, userState, dialog);
        // Creates a new user property accessor.
        this.welcomeUserProperty = userState.createProperty(WELCOMED_USER);

        this.userState = userState;

        // Send welcome messages to conversation members when they join the conversation
        // Messages are only sent to conversation members who are arent the bot
        this.onMembersAdded(async (context, next) => {
            // Iterate over all new mewmbers to conversation
            for (const idx in context.activity.membersAdded) {
                // Greet anyone that was not the target of this message
                // Since the bot is the recipient for events from the channel,
                // context.activity.membersAdded === context.activity.recipient.Id indicates the
                // bot was added to the conversation, and the opposite indicates this is a user.
                if (context.activity.membersAdded[idx].id !== context.activity.recipient.id) {
                    await context.sendActivity(`Welcome to Alfar. We will help you buy and sell real estate properties.`);
                }
            }

            // By calling next() you ensure that the next BotHandler is run
            await next();
        });
    }
}

module.exports.WelcomeBot = WelcomeBot;
